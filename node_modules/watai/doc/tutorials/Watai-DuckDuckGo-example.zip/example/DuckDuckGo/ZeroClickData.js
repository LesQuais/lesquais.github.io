lookupTerm = "Toto"
